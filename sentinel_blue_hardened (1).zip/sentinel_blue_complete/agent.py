from __future__ import annotations

import argparse
import glob
import grp
import os
import pwd
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Any

import psutil
import requests

from rules import ADMIN_GROUPS, COMMON_SERVICE_PORTS, SHELL_LOGIN_DENY, SYSTEM_USERS, infer_roles, process_suspicion
from shared import bounded_list, command_exists, digest_text, ensure_dir, http_probe, read_json, safe_run, sha256_file, tcp_connect, utc_now, write_json

DEFAULT_INTERVAL = 20
AGENT_DIR = ensure_dir(Path.home() / '.sentinel_blue_agent')
STATE_FILE = AGENT_DIR / 'state.json'
BASELINE_DIR = ensure_dir(AGENT_DIR / 'baselines')
FILE_BACKUP_DIR = ensure_dir(AGENT_DIR / 'file_backups')

SERVICE_CONFIG_GUESSES: dict[str, list[str]] = {
	'ssh': ['/etc/ssh/sshd_config'],
	'dns': ['/etc/bind/named.conf', '/etc/bind/named.conf.options', '/etc/bind/named.conf.local', '/etc/dnsmasq.conf', '/etc/unbound/unbound.conf'],
	'web': ['/etc/nginx/nginx.conf', '/etc/apache2/apache2.conf', '/etc/httpd/conf/httpd.conf', '/etc/nginx/sites-enabled/*', '/etc/apache2/sites-enabled/*'],
	'smb': ['/etc/samba/smb.conf'],
	'postgres': ['/etc/postgresql/*/main/postgresql.conf', '/etc/postgresql/*/main/pg_hba.conf', '/var/lib/pgsql/data/postgresql.conf', '/var/lib/pgsql/data/pg_hba.conf'],
}
PROFILE_STARTUP_PATTERNS = [
	'~/.bashrc', '~/.profile', '~/.bash_profile', '~/.zshrc', '~/.config/autostart/*.desktop', '~/.config/systemd/user/*.service',
]


class Agent:
	def __init__(self, controller: str, token: str, interval: int, name: str | None = None, expectations_path: str | None = None) -> None:
		self.controller = controller.rstrip('/')
		self.token = token
		self.interval = interval
		self.host_id = name or socket.gethostname()
		self.session = requests.Session()
		self.state = read_json(STATE_FILE, default=None) or {
			'log_offsets': {},
			'recent_observation_hashes': [],
			'baseline_name': None,
		}
		self.expectations = read_json(expectations_path, default={}) if expectations_path else {}

	def headers(self) -> dict[str, str]:
		return {'X-Sentinel-Token': self.token, 'Content-Type': 'application/json'}

	def save_state(self) -> None:
		write_json(STATE_FILE, self.state)

	def _os_release(self) -> dict[str, str]:
		info: dict[str, str] = {}
		path = Path('/etc/os-release')
		if path.exists():
			for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
				if '=' not in line:
					continue
				k, v = line.split('=', 1)
				info[k] = v.strip().strip('"')
		return info

	def _local_ips(self) -> list[str]:
		ips: list[str] = []
		for _, addrs in psutil.net_if_addrs().items():
			for addr in addrs:
				if addr.family == socket.AF_INET and addr.address:
					ips.append(addr.address)
		return sorted(set(ips))

	def _packages(self) -> list[str]:
		for cmd in (['rpm', '-qa'], ['dpkg-query', '-W', '-f', '${Package}\n']):
			rc, out, _ = safe_run(cmd, timeout=45)
			if rc == 0 and out:
				rows = [line.strip() for line in out.splitlines() if line.strip()]
				if cmd[0] == 'rpm':
					rows = [line.split('-', 1)[0] for line in rows]
				return sorted(set(rows))[:4000]
		return []

	def _service_rows(self) -> list[dict[str, Any]]:
		rows: list[dict[str, Any]] = []
		rc, out, _ = safe_run(['systemctl', 'list-units', '--type=service', '--all', '--no-pager', '--no-legend'], timeout=25)
		if rc == 0 and out:
			for line in out.splitlines():
				parts = re.split(r'\s+', line.strip(), maxsplit=4)
				if len(parts) >= 4:
					name, load_state, active_state, sub_state = parts[:4]
					rows.append({'name': name.replace('.service', ''), 'unit': name, 'load_state': load_state, 'active_state': active_state, 'sub_state': sub_state})
		return rows

	def _enabled_services(self) -> set[str]:
		rc, out, _ = safe_run(['systemctl', 'list-unit-files', '--type=service', '--no-pager', '--no-legend'], timeout=30)
		enabled: set[str] = set()
		if rc == 0 and out:
			for line in out.splitlines():
				parts = re.split(r'\s+', line.strip())
				if len(parts) >= 2 and parts[1] == 'enabled':
					enabled.add(parts[0].replace('.service', ''))
		return enabled

	def _users(self) -> list[dict[str, Any]]:
		rows: list[dict[str, Any]] = []
		group_map: dict[str, list[str]] = {}
		for group in grp.getgrall():
			for member in group.gr_mem:
				group_map.setdefault(member, []).append(group.gr_name)
		for entry in pwd.getpwall():
			groups = set(group_map.get(entry.pw_name, []))
			try:
				primary_group = grp.getgrgid(entry.pw_gid).gr_name
				groups.add(primary_group)
			except KeyError:
				pass
			rows.append({
				'name': entry.pw_name,
				'uid': entry.pw_uid,
				'gid': entry.pw_gid,
				'home': entry.pw_dir,
				'shell': entry.pw_shell,
				'groups': sorted(groups),
			})
		return sorted(rows, key=lambda x: (x['uid'], x['name']))

	def _logged_in_users(self) -> list[dict[str, Any]]:
		rows: list[dict[str, Any]] = []
		for item in psutil.users():
			rows.append({
				'username': item.name,
				'terminal': item.terminal or '',
				'host': item.host or '',
				'started': item.started,
			})
		return rows

	def _startup_items(self) -> list[dict[str, Any]]:
		rows: list[dict[str, Any]] = []
		for path in ['/etc/crontab', '/etc/anacrontab']:
			p = Path(path)
			if p.exists():
				rows.append({'key': path, 'type': 'cron_file', 'path': path, 'sha256': sha256_file(p)})
		for pattern in ['/etc/cron.d/*', '/etc/cron.daily/*', '/etc/cron.hourly/*', '/etc/cron.weekly/*', '/etc/cron.monthly/*']:
			for path in sorted(glob.glob(pattern)):
				p = Path(path)
				if p.is_file():
					rows.append({'key': path, 'type': 'cron_entry', 'path': path, 'sha256': sha256_file(p)})
		rc, out, _ = safe_run(['systemctl', 'list-unit-files', '--type=service,timer', '--no-legend', '--no-pager'], timeout=25)
		if rc == 0:
			for line in out.splitlines():
				parts = re.split(r'\s+', line.strip())
				if len(parts) >= 2 and parts[1] == 'enabled':
					unit = parts[0]
					item_type = 'systemd_timer' if unit.endswith('.timer') else 'systemd_enabled'
					rows.append({'key': f'systemd:{unit}', 'type': item_type, 'path': unit})
		return rows[:700]

	def _persistence_items(self, users: list[dict[str, Any]]) -> list[dict[str, Any]]:
		rows = list(self._startup_items())
		for path in ['/etc/ld.so.preload', '/etc/rc.local', '/etc/sudoers']:
			p = Path(path)
			if p.exists() and p.is_file():
				kind = 'ld_preload' if path.endswith('ld.so.preload') else 'rc_local' if path.endswith('rc.local') else 'sudoers'
				rows.append({'key': path, 'type': kind, 'path': path, 'sha256': sha256_file(p)})
		for pattern in ['/etc/sudoers.d/*', '/etc/ssh/sshd_config.d/*']:
			for path in sorted(glob.glob(pattern)):
				p = Path(path)
				if p.is_file():
					kind = 'sudoers' if '/sudoers' in path else 'ssh_dropin'
					rows.append({'key': path, 'type': kind, 'path': path, 'sha256': sha256_file(p)})
		for user in users:
			name = user.get('name', '')
			home = user.get('home', '')
			if not home or not Path(home).exists():
				continue
			ssh_key = Path(home) / '.ssh' / 'authorized_keys'
			if ssh_key.exists() and ssh_key.is_file():
				rows.append({'key': f'authorized_keys:{name}', 'type': 'authorized_keys', 'path': str(ssh_key), 'user': name, 'sha256': sha256_file(ssh_key)})
			rc, out, _ = safe_run(['crontab', '-l', '-u', name], timeout=10)
			if rc == 0 and out and 'no crontab for' not in out.lower():
				rows.append({'key': f'user_crontab:{name}', 'type': 'user_crontab', 'path': f'crontab:{name}', 'user': name, 'sha256': digest_text(out)})
			for pattern in PROFILE_STARTUP_PATTERNS:
				expanded = pattern.replace('~', home)
				for path in sorted(glob.glob(expanded)):
					p = Path(path)
					if p.is_file():
						ptype = 'systemd_user_service' if '/systemd/user/' in path else 'profile_startup'
						rows.append({'key': f'{ptype}:{name}:{path}', 'type': ptype, 'path': path, 'user': name, 'sha256': sha256_file(p)})
		return rows[:1500]

	def _listeners_and_connections(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[int, list[int]]]:
		listeners: list[dict[str, Any]] = []
		connections: list[dict[str, Any]] = []
		pid_to_ports: dict[int, list[int]] = {}
		seen_listener_keys: set[str] = set()
		for conn in psutil.net_connections(kind='inet'):
			pid = conn.pid if conn.pid is not None else -1
			if conn.status == psutil.CONN_LISTEN and conn.laddr:
				ip = getattr(conn.laddr, 'ip', '')
				port = int(getattr(conn.laddr, 'port', 0))
				key = f'{ip}:{port}:{pid}'
				if key not in seen_listener_keys:
					seen_listener_keys.add(key)
					listeners.append({'key': key, 'ip': ip, 'port': port, 'pid': pid, 'service_guess': COMMON_SERVICE_PORTS.get(port, 'unknown')})
					if pid >= 0:
						pid_to_ports.setdefault(pid, []).append(port)
			elif conn.raddr:
				connections.append({
					'pid': pid,
					'status': conn.status,
					'local_ip': getattr(conn.laddr, 'ip', ''),
					'local_port': int(getattr(conn.laddr, 'port', 0) or 0),
					'remote_ip': getattr(conn.raddr, 'ip', ''),
					'remote_port': int(getattr(conn.raddr, 'port', 0) or 0),
				})
		return listeners, connections[:1000], pid_to_ports

	def _processes(self, pid_to_ports: dict[int, list[int]]) -> list[dict[str, Any]]:
		rows: list[dict[str, Any]] = []
		for proc in psutil.process_iter(['pid', 'name', 'username', 'cmdline', 'exe', 'cwd']):
			try:
				info = proc.info
				row = {
					'pid': info['pid'],
					'name': info.get('name') or '',
					'username': info.get('username') or '',
					'cmdline': info.get('cmdline') or [],
					'exe': info.get('exe') or '',
					'cwd': info.get('cwd') or '',
					'listening_ports': sorted(pid_to_ports.get(info['pid'], [])),
				}
				row['suspicion'] = process_suspicion(row)
				rows.append(row)
			except (psutil.NoSuchProcess, psutil.AccessDenied):
				continue
		rows.sort(key=lambda x: (x['suspicion'], x['pid']), reverse=True)
		return rows[:700]

	def _ip_forwarding(self) -> bool:
		path = Path('/proc/sys/net/ipv4/ip_forward')
		if path.exists():
			return path.read_text().strip() == '1'
		return False

	def _default_route_present(self) -> bool:
		rc, out, _ = safe_run(['ip', 'route', 'show', 'default'], timeout=10)
		return rc == 0 and bool(out.strip())

	def _firewall_summary(self) -> dict[str, Any]:
		for cmd in (['nft', 'list', 'ruleset'], ['iptables-save'], ['ufw', 'status', 'numbered'], ['firewall-cmd', '--list-all']):
			rc, out, err = safe_run(cmd, timeout=25)
			if rc == 0 and out:
				return {'tool': cmd[0], 'present': True, 'sample': '\n'.join(out.splitlines()[:20]), 'error': ''}
			if rc == 0 and err:
				return {'tool': cmd[0], 'present': True, 'sample': err, 'error': ''}
		return {'tool': 'unknown', 'present': False, 'sample': '', 'error': ''}

	def _expectation_for(self, service: str) -> dict[str, Any]:
		return self.expectations.get(service, {}) if isinstance(self.expectations, dict) else {}

	def _dns_probe(self, exp: dict[str, Any]) -> tuple[bool, str]:
		server = exp.get('server', '127.0.0.1')
		name = exp.get('query_name', 'localhost')
		qtype = exp.get('query_type', 'A')
		if command_exists('dig'):
			rc, out, err = safe_run(['dig', '+time=1', '+tries=1', f'@{server}', name, qtype], timeout=5)
			text = out or err
			if rc == 0 and text and 'connection timed out' not in text.lower() and 'no servers could be reached' not in text.lower():
				if 'status: NOERROR' in text or 'status: NXDOMAIN' in text:
					return True, f'dig response for {name} {qtype}'
				return False, 'dig answered but returned unexpected status'
		return tcp_connect(server, 53, timeout=1.0), 'tcp listener on port 53' if tcp_connect(server, 53, timeout=1.0) else 'port 53 not reachable'

	def _postgres_probe(self, exp: dict[str, Any], probe_ip: str) -> tuple[bool, str]:
		port = int(exp.get('port', 5432))
		if command_exists('pg_isready'):
			cmd = ['pg_isready', '-q', '-h', probe_ip, '-p', str(port)]
			if exp.get('database'):
				cmd.extend(['-d', str(exp['database'])])
			rc, _, err = safe_run(cmd, timeout=5)
			return rc == 0, 'pg_isready succeeded' if rc == 0 else (err or 'pg_isready failed')
		return tcp_connect(probe_ip, port, timeout=2.0), f'tcp connect to {probe_ip}:{port}'

	def _service_health(self, snapshot: dict[str, Any]) -> list[dict[str, Any]]:
		health: list[dict[str, Any]] = []
		listeners = {x['port'] for x in snapshot.get('listeners', [])}
		service_rows = {x['name']: x for x in snapshot.get('services', [])}
		service_names = {x['name'] for x in snapshot.get('services', []) if x.get('active_state') == 'active'}
		roles = infer_roles(snapshot)
		ips = snapshot.get('local_ips', []) or ['127.0.0.1']
		probe_ip = next((candidate for candidate in ips if candidate != '127.0.0.1'), '127.0.0.1')

		def add(service: str, status: str, detail: str) -> None:
			health.append({'service': service, 'status': status, 'detail': detail})

		if 'ssh' in roles:
			port_up = 22 in listeners and tcp_connect(probe_ip, 22)
			service_ok = any(name in service_names for name in ('ssh', 'sshd'))
			status = 'up' if port_up and service_ok else 'degraded' if port_up or service_ok else 'down'
			detail = 'sshd active and reachable' if status == 'up' else 'sshd partially healthy' if status == 'degraded' else 'sshd listener or service missing'
			add('ssh', status, detail)
		if 'web' in roles:
			exp = self._expectation_for('web')
			http_ok = False
			https_ok = False
			detail_bits: list[str] = []
			if 80 in listeners:
				ok, status_code, body = http_probe(exp.get('url', f'http://{probe_ip}/'))
				http_ok = ok or (status_code is not None and status_code < 500)
				if http_ok:
					detail_bits.append(f'http {status_code or 200}')
					needle = exp.get('contains')
					if needle and needle not in body:
						http_ok = False
						detail_bits.append('expected content string missing')
				else:
					detail_bits.append(str(body)[:80])
			if 443 in listeners:
				ok, status_code, body = http_probe(exp.get('https_url', f'https://{probe_ip}/'))
				https_ok = ok or (status_code is not None and status_code < 500)
				if https_ok:
					detail_bits.append(f'https {status_code or 200}')
					needle = exp.get('ssl_contains') or exp.get('contains')
					if needle and needle not in body:
						https_ok = False
						detail_bits.append('expected ssl content string missing')
				else:
					detail_bits.append(str(body)[:80])
			if http_ok or https_ok:
				status = 'up'
			elif 80 in listeners or 443 in listeners:
				status = 'degraded'
			else:
				status = 'down'
			add('web', status, '; '.join(detail_bits) or 'no web listener found')
		if 'smb' in roles:
			port_up = 445 in listeners or 139 in listeners
			cfg_ok = True
			if command_exists('testparm'):
				rc, _, err = safe_run(['testparm', '-s', '--parameter-name=server role'], timeout=10)
				cfg_ok = rc == 0
				detail = 'samba listener and config look healthy' if port_up and cfg_ok else err or 'samba config check failed'
			else:
				detail = 'samba listener check'
			status = 'up' if port_up and cfg_ok else 'degraded' if port_up else 'down'
			add('smb', status, detail)
		if 'database' in roles:
			service_name = 'postgres' if 5432 in listeners or 'postgres' in service_names or 'postgresql' in service_names else 'database'
			exp = self._expectation_for('postgres') if service_name == 'postgres' else {}
			up, detail = self._postgres_probe(exp, probe_ip)
			status = 'up' if up else 'degraded' if (5432 in listeners or 3306 in listeners) else 'down'
			add(service_name, status, detail)
		if 'dns' in roles:
			exp = self._expectation_for('dns')
			up, detail = self._dns_probe(exp)
			status = 'up' if up else 'degraded' if 53 in listeners else 'down'
			add('dns', status, detail)
		if 'router' in roles:
			forward = snapshot.get('ip_forwarding')
			default_route = snapshot.get('default_route_present', False)
			status = 'up' if forward and default_route else 'degraded' if forward or default_route else 'down'
			detail = 'IP forwarding enabled and default route present' if status == 'up' else 'routing host partially configured' if status == 'degraded' else 'routing configuration missing'
			add('router', status, detail)
		if not health:
			add('generic_linux', 'up', 'generic host baseline only')
		return health

	def _log_tail(self, path: str, max_lines: int = 250) -> list[str]:
		p = Path(path)
		if not p.exists() or not p.is_file():
			return []
		try:
			with p.open('r', encoding='utf-8', errors='ignore') as fh:
				lines = fh.readlines()[-max_lines:]
			return [x.rstrip('\n') for x in lines]
		except OSError:
			return []

	def _journal_lines(self, unit: str | None = None, since: str = '-5m', max_lines: int = 200) -> list[str]:
		cmd = ['journalctl', '--no-pager', '-n', str(max_lines), '--since', since]
		if unit:
			cmd.extend(['-u', unit])
		rc, out, _ = safe_run(cmd, timeout=20)
		return out.splitlines() if rc == 0 and out else []

	def _observe_logs(self) -> list[dict[str, Any]]:
		obs: list[dict[str, Any]] = []
		patterns = [
			('ssh_auth', self._log_tail('/var/log/auth.log') + self._log_tail('/var/log/secure') + self._journal_lines('sshd'), self._parse_ssh_line),
			('samba', sum((self._log_tail(p) for p in glob.glob('/var/log/samba/*')), [])[:250], self._parse_samba_line),
			('postgres', sum((self._log_tail(p) for p in glob.glob('/var/log/postgresql/*.log') + glob.glob('/var/lib/pgsql/data/log/*')), [])[:250], self._parse_postgres_line),
			('nginx', self._log_tail('/var/log/nginx/access.log') + self._log_tail('/var/log/apache2/access.log') + self._log_tail('/var/log/httpd/access_log'), self._parse_web_line),
			('dns', self._journal_lines('named') + self._journal_lines('bind9') + self._journal_lines('dnsmasq') + self._journal_lines('unbound'), self._parse_dns_line),
		]
		recent_hashes = set(self.state.get('recent_observation_hashes', []))
		for _, lines, parser in patterns:
			for line in lines[-250:]:
				for item in parser(line):
					fingerprint = digest_text(f"{item.get('service')}|{item.get('username')}|{item.get('source_ip')}|{item.get('action')}|{line}")
					if fingerprint in recent_hashes:
						continue
					recent_hashes.add(fingerprint)
					item['timestamp'] = utc_now()
					item['raw'] = line[:500]
					obs.append(item)
		self.state['recent_observation_hashes'] = list(recent_hashes)[-4000:]
		return bounded_list(obs, 400)

	def _parse_ssh_line(self, line: str) -> list[dict[str, Any]]:
		rows = []
		m = re.search(r'Accepted \S+ for ([A-Za-z0-9_.-]+) from ([0-9a-fA-F:.]+)', line)
		if m:
			rows.append({'service': 'ssh', 'username': m.group(1), 'source_ip': m.group(2), 'action': 'login_success'})
		m = re.search(r'Failed \S+ for (?:invalid user )?([A-Za-z0-9_.-]+) from ([0-9a-fA-F:.]+)', line)
		if m:
			rows.append({'service': 'ssh', 'username': m.group(1), 'source_ip': m.group(2), 'action': 'login_fail'})
		return rows

	def _parse_samba_line(self, line: str) -> list[dict[str, Any]]:
		rows = []
		m = re.search(r'connect to service .* initially as user ([A-Za-z0-9_.-]+)', line)
		if m:
			rows.append({'service': 'smb', 'username': m.group(1), 'source_ip': '', 'action': 'login_success'})
		m2 = re.search(r'from (?:ipv4:)?([0-9a-fA-F:.]+)', line)
		ip = m2.group(1) if m2 else ''
		if 'opened file' in line.lower():
			m3 = re.search(r'user ([A-Za-z0-9_.-]+)', line)
			if m3:
				rows.append({'service': 'smb', 'username': m3.group(1), 'source_ip': ip, 'action': 'read'})
		return rows

	def _parse_postgres_line(self, line: str) -> list[dict[str, Any]]:
		rows = []
		m = re.search(r'user=([A-Za-z0-9_.-]+),db=([A-Za-z0-9_.-]+),app=', line)
		if m:
			rows.append({'service': 'postgres', 'username': m.group(1), 'source_ip': '', 'action': 'query'})
		if 'password authentication failed for user' in line:
			m2 = re.search(r'user "([A-Za-z0-9_.-]+)"', line)
			if m2:
				rows.append({'service': 'postgres', 'username': m2.group(1), 'source_ip': '', 'action': 'login_fail'})
		return rows

	def _parse_web_line(self, line: str) -> list[dict[str, Any]]:
		rows = []
		m = re.search(r'^([0-9a-fA-F:.]+) .* "(GET|POST|PUT|HEAD) ', line)
		if m:
			rows.append({'service': 'web', 'username': '-', 'source_ip': m.group(1), 'action': 'http'})
		return rows

	def _parse_dns_line(self, line: str) -> list[dict[str, Any]]:
		rows = []
		m = re.search(r'client @0x[0-9a-f]+ ([0-9a-fA-F:.]+)#\d+ \((.*?)\): query:', line)
		if m:
			rows.append({'service': 'dns', 'username': '-', 'source_ip': m.group(1), 'action': 'dns'})
		return rows

	def _config_candidates(self, roles: list[str]) -> list[str]:
		paths: list[str] = []
		for role in roles:
			for service, candidates in SERVICE_CONFIG_GUESSES.items():
				if (role == 'web' and service == 'web') or (role == 'ssh' and service == 'ssh') or (role == 'dns' and service == 'dns') or (role == 'smb' and service == 'smb') or (role == 'database' and service == 'postgres'):
					for pattern in candidates:
						for path in glob.glob(pattern):
							if Path(path).exists():
								paths.append(path)
		return sorted(set(paths))

	def _backup_path_for(self, path: str) -> Path:
		safe_name = path.lstrip('/').replace('/', '__')
		return FILE_BACKUP_DIR / safe_name

	def create_baseline(self) -> dict[str, Any]:
		snapshot = self.collect_state(include_observations=False)
		roles = snapshot['roles']
		baseline_name = time.strftime('%Y%m%d-%H%M%S')
		root = ensure_dir(BASELINE_DIR / baseline_name)
		for cfg in self._config_candidates(roles):
			p = Path(cfg)
			if p.exists() and p.is_file():
				target = root / p.relative_to('/')
				target.parent.mkdir(parents=True, exist_ok=True)
				try:
					shutil.copy2(p, target)
				except OSError:
					pass
		self.state['baseline_name'] = baseline_name
		self.save_state()
		return {'ok': True, 'baseline_name': baseline_name, 'files': len(list(root.rglob('*'))), 'timestamp': utc_now()}

	def _restore_file_from_baseline(self, path: str) -> tuple[bool, str]:
		baseline_name = self.state.get('baseline_name')
		if not baseline_name:
			return False, 'no baseline has been created on this host yet'
		source = BASELINE_DIR / baseline_name / Path(path).relative_to('/')
		if not source.exists():
			return False, f'baseline copy not found for {path}'
		backup = self._backup_path_for(path)
		try:
			backup.parent.mkdir(parents=True, exist_ok=True)
			if Path(path).exists():
				shutil.copy2(path, backup)
			shutil.copy2(source, path)
			return True, f'restored {path} from baseline {baseline_name}'
		except OSError as exc:
			return False, f'failed to restore {path}: {exc}'

	def collect_state(self, include_observations: bool = True) -> dict[str, Any]:
		os_release = self._os_release()
		listeners, connections, pid_to_ports = self._listeners_and_connections()
		services = self._service_rows()
		enabled = self._enabled_services()
		for row in services:
			row['enabled'] = row['name'] in enabled
		packages = self._packages()
		users = self._users()
		snapshot = {
			'host_id': self.host_id,
			'timestamp': utc_now(),
			'hostname': socket.gethostname(),
			'fqdn': socket.getfqdn(),
			'local_ips': self._local_ips(),
			'os_release': os_release,
			'users': users,
			'logged_in_users': self._logged_in_users(),
			'services': services,
			'packages': packages,
			'listeners': listeners,
			'connections': connections,
			'processes': self._processes(pid_to_ports),
			'startup_items': self._startup_items(),
			'persistence_items': self._persistence_items(users),
			'ip_forwarding': self._ip_forwarding(),
			'default_route_present': self._default_route_present(),
			'firewall': self._firewall_summary(),
		}
		snapshot['roles'] = infer_roles(snapshot)
		snapshot['health'] = self._service_health(snapshot)
		if include_observations:
			snapshot['observations'] = self._observe_logs()
		else:
			snapshot['observations'] = []
		return snapshot

	def _restart_service(self, service: str, reload_only: bool = False) -> tuple[bool, str]:
		candidates = {
			'ssh': ['ssh', 'sshd'],
			'dns': ['named', 'bind9', 'dnsmasq', 'unbound'],
			'web': ['nginx', 'apache2', 'httpd'],
			'smb': ['smbd', 'nmbd'],
			'postgres': ['postgresql', 'postgres'],
		}
		units = candidates.get(service, [service])
		verb = 'reload' if reload_only else 'restart'
		last_err = ''
		for unit in units:
			rc, _, err = safe_run(['systemctl', verb, unit], timeout=30)
			if rc == 0:
				return True, f'{verb}ed {unit}'
			last_err = err
		return False, f'failed to {verb} any unit for {service}: {last_err}'

	def _protected_user_reason(self, username: str) -> str | None:
		if username == 'root':
			return 'root is always protected'
		try:
			entry = pwd.getpwnam(username)
		except KeyError:
			return None
		if entry.pw_uid < 1000:
			return 'system or service account'
		if username in SYSTEM_USERS:
			return 'known protected service account'
		if username == pwd.getpwuid(os.getuid()).pw_name:
			return 'current agent execution user'
		return None

	def _lock_user(self, username: str, disable_shell: bool = False, allow_protected: bool = False) -> tuple[bool, str]:
		if not allow_protected:
			reason = self._protected_user_reason(username)
			if reason:
				return False, f'refused to modify protected account {username}: {reason}'
		rc, _, err = safe_run(['passwd', '-l', username], timeout=20)
		if rc != 0:
			return False, err or f'passwd -l failed for {username}'
		if disable_shell:
			nologin = '/usr/sbin/nologin' if Path('/usr/sbin/nologin').exists() else '/sbin/nologin' if Path('/sbin/nologin').exists() else '/bin/false'
			safe_run(['usermod', '-s', nologin, username], timeout=20)
		return True, f'locked account {username}'

	def _delete_user(self, username: str, allow_protected: bool = False) -> tuple[bool, str]:
		if not allow_protected:
			reason = self._protected_user_reason(username)
			if reason:
				return False, f'refused to delete protected account {username}: {reason}'
		rc, _, err = safe_run(['userdel', '-r', username], timeout=25)
		return (rc == 0, err or f'deleted {username}')

	def _terminate_sessions(self, username: str, allow_protected: bool = False) -> tuple[bool, str]:
		if not allow_protected:
			reason = self._protected_user_reason(username)
			if reason:
				return False, f'refused to terminate sessions for protected account {username}: {reason}'
		rc, _, err = safe_run(['pkill', '-KILL', '-u', username], timeout=20)
		if rc in {0, 1}:
			return True, f'terminated sessions for {username}'
		return False, err or f'failed to terminate sessions for {username}'

	def _kill_process(self, pid: int, allow_protected: bool = False) -> tuple[bool, str]:
		try:
			proc = psutil.Process(pid)
			name = (proc.name() or '').lower()
			username = proc.username() or ''
			ports = set()
			for conn in proc.net_connections(kind='inet'):
				if conn.status == psutil.CONN_LISTEN and conn.laddr:
					ports.add(int(getattr(conn.laddr, 'port', 0) or 0))
			if not allow_protected:
				if pid <= 1:
					return False, 'refused to kill pid 1 or below'
				if username in SYSTEM_USERS | {'root'} and (ports & set(COMMON_SERVICE_PORTS) or name in {'sshd', 'named', 'dnsmasq', 'nginx', 'apache2', 'httpd', 'postgres', 'postgresql', 'smbd'}):
					return False, f'refused to kill likely critical service process {pid} ({name})'
			proc.kill()
			return True, f'killed pid {pid}'
		except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
			return False, str(exc)

	def _rotate_password(self, username: str, new_password: str, allow_protected: bool = False) -> tuple[bool, str]:
		if not new_password or len(new_password) < 10:
			return False, 'new password must be at least 10 characters long'
		if not allow_protected:
			reason = self._protected_user_reason(username)
			if reason:
				return False, f'refused to rotate password for protected account {username}: {reason}'
		proc = subprocess.run(['chpasswd'], input=f'{username}:{new_password}', text=True, capture_output=True, check=False)
		return (proc.returncode == 0, proc.stderr.strip() or f'password changed for {username}')

	def run_action(self, action: dict[str, Any]) -> dict[str, Any]:
		name = action.get('action')
		params = action.get('params', {})
		ok = False
		message = 'unsupported action'
		validation: list[dict[str, Any]] = []
		allow_protected = bool(params.get('allow_protected'))
		if name == 'create_baseline':
			return self.create_baseline()
		elif name == 'restart_service':
			ok, message = self._restart_service(params['service'], reload_only=False)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'reload_service':
			ok, message = self._restart_service(params['service'], reload_only=True)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'restore_service_config':
			service = params['service']
			results = []
			for pattern in SERVICE_CONFIG_GUESSES.get(service, []):
				for path in glob.glob(pattern):
					restored, msg = self._restore_file_from_baseline(path)
					results.append(msg)
			ok = any('restored' in x for x in results)
			message = '; '.join(results) if results else f'no config guesses for {service}'
			if ok:
				self._restart_service(service, reload_only=False)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'lock_user':
			ok, message = self._lock_user(params['username'], disable_shell=False, allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'disable_user':
			ok, message = self._lock_user(params['username'], disable_shell=True, allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'delete_user':
			ok, message = self._delete_user(params['username'], allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'terminate_user_sessions':
			ok, message = self._terminate_sessions(params['username'], allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'kill_process':
			ok, message = self._kill_process(int(params['pid']), allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		elif name == 'rotate_password':
			ok, message = self._rotate_password(params['username'], params['new_password'], allow_protected=allow_protected)
			validation = self._service_health(self.collect_state(include_observations=False))
		return {'ok': ok, 'message': message, 'validation': validation, 'timestamp': utc_now()}

	def send_heartbeat(self) -> None:
		report = self.collect_state(include_observations=True)
		resp = self.session.post(f'{self.controller}/api/heartbeat', json=report, headers=self.headers(), timeout=20)
		resp.raise_for_status()
		self.save_state()

	def poll_commands(self) -> None:
		resp = self.session.get(f'{self.controller}/api/commands/{self.host_id}', headers=self.headers(), timeout=20)
		resp.raise_for_status()
		commands = resp.json().get('commands', [])
		for command in commands:
			result = self.run_action(command)
			self.session.post(f"{self.controller}/api/command_result/{command['id']}", json=result, headers=self.headers(), timeout=20).raise_for_status()

	def run_forever(self) -> None:
		while True:
			try:
				self.send_heartbeat()
				self.poll_commands()
			except Exception as exc:
				print(f'[{utc_now()}] agent error: {exc}')
			finally:
				time.sleep(self.interval)


def main() -> None:
	parser = argparse.ArgumentParser(description='Sentinel Blue Linux Agent')
	parser.add_argument('--controller', required=True, help='Controller base URL, example: http://192.168.1.10:8989')
	parser.add_argument('--token', default=os.environ.get('SENTINEL_BLUE_TOKEN', ''))
	parser.add_argument('--interval', type=int, default=DEFAULT_INTERVAL)
	parser.add_argument('--name', default=None)
	parser.add_argument('--expectations', default=None, help='Optional JSON file with service expectations for content or role-specific checks.')
	args = parser.parse_args()
	if not args.token:
		raise SystemExit('A shared token is required. Set --token or SENTINEL_BLUE_TOKEN.')
	agent = Agent(controller=args.controller, token=args.token, interval=args.interval, name=args.name, expectations_path=args.expectations)
	agent.run_forever()


if __name__ == '__main__':
	main()
