from __future__ import annotations

import ipaddress
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

SYSTEM_USERS = {
	'root', 'daemon', 'bin', 'sys', 'sync', 'games', 'man', 'lp', 'mail', 'news', 'uucp', 'proxy', 'www-data',
	'backup', 'list', 'irc', '_apt', 'nobody', 'systemd-network', 'systemd-resolve', 'messagebus', 'polkitd',
	'redis', 'dnsmasq', 'sshd', 'mysql', 'mariadb', 'postgres', 'postfix', 'bind', 'named', 'chrony', 'ntp',
	'dbus', 'avahi', 'ftp', 'tftp', 'rpc', 'rpcuser', 'nfsnobody', 'apache', 'nginx', 'tomcat', 'rabbitmq',
	'elasticsearch', 'grafana', 'prometheus', 'splunk', 'clamav', 'syslog', 'uuidd', 'cups-pk-helper',
	'systemd-timesync', 'systemd-oom', 'systemd-coredump', 'ssm-user', 'ec2-user',
}

ADMIN_GROUPS = {'sudo', 'wheel', 'adm'}
SHELL_LOGIN_DENY = {'/usr/sbin/nologin', '/sbin/nologin', '/bin/false', 'nologin', 'false'}
DANGEROUS_PROCESS_PATH_FRAGMENTS = ['/tmp/', '/var/tmp/', '/dev/shm/', '/run/user/', '/home/', '/srv/ftp/']
SUSPICIOUS_PROCESS_NAMES = {'nc', 'ncat', 'netcat', 'socat', 'curl', 'wget', 'python', 'python3', 'perl', 'ruby', 'bash', 'sh'}
COMMON_SERVICE_PORTS: dict[int, str] = {
	22: 'ssh',
	53: 'dns',
	80: 'http',
	443: 'https',
	445: 'smb',
	5432: 'postgres',
	3306: 'mysql',
	25: 'smtp',
	110: 'pop3',
	143: 'imap',
	389: 'ldap',
	636: 'ldaps',
	3389: 'rdp',
	139: 'netbios',
}
ROLE_PORTS: dict[str, set[int]] = {
	'router': set(),
	'ssh': {22},
	'dns': {53},
	'web': {80, 443},
	'smb': {445, 139},
	'database': {5432, 3306},
}
ROLE_SERVICE_HINTS: dict[str, tuple[str, ...]] = {
	'router': ('nftables', 'iptables', 'ufw', 'firewalld', 'bird', 'frr', 'NetworkManager'),
	'ssh': ('ssh', 'sshd'),
	'dns': ('bind', 'named', 'dnsmasq', 'unbound', 'pdns', 'powerdns'),
	'web': ('nginx', 'apache2', 'httpd', 'lighttpd', 'caddy'),
	'smb': ('smbd', 'nmbd', 'winbind'),
	'database': ('postgresql', 'postgres', 'mariadb', 'mysqld'),
}
HIGH_RISK_PERSISTENCE_TYPES = {
	'user_crontab', 'systemd_timer', 'systemd_user_service', 'authorized_keys', 'sudoers', 'ld_preload',
	'rc_local', 'profile_startup', 'cron_entry', 'cron_file', 'systemd_enabled',
}


def parse_time(value: str | None) -> datetime | None:
	if not value:
		return None
	try:
		return datetime.fromisoformat(value.replace('Z', '+00:00'))
	except ValueError:
		return None


def infer_roles(snapshot: dict[str, Any]) -> list[str]:
	roles: set[str] = set()
	listeners = {int(x['port']) for x in snapshot.get('listeners', []) if isinstance(x.get('port'), int)}
	service_names = {x.get('name', '').lower() for x in snapshot.get('services', [])}
	packages = {x.lower() for x in snapshot.get('packages', [])}
	combined = service_names | packages

	for role, ports in ROLE_PORTS.items():
		if listeners & ports:
			roles.add(role)
	for role, hints in ROLE_SERVICE_HINTS.items():
		for hint in hints:
			needle = hint.lower()
			if any(needle in item for item in combined):
				roles.add(role)
				break
	if snapshot.get('ip_forwarding'):
		roles.add('router')
	if not roles:
		roles.add('generic_linux')
	return sorted(roles)


def process_suspicion(proc: dict[str, Any]) -> int:
	score = 0
	name = str(proc.get('name', '')).lower()
	exe = str(proc.get('exe', '')).lower()
	cmdline = ' '.join(proc.get('cmdline', [])).lower()
	username = str(proc.get('username', '')).lower()
	ports = {int(p) for p in proc.get('listening_ports', []) if isinstance(p, int)}
	for frag in DANGEROUS_PROCESS_PATH_FRAGMENTS:
		if frag in exe or frag in cmdline:
			score += 2
	if name in SUSPICIOUS_PROCESS_NAMES and any(token in cmdline for token in ('http', 'https', 'tcp', '/tmp/', 'bash -c', 'python -c', '/dev/tcp/')):
		score += 2
	if username not in SYSTEM_USERS and username not in {'root', ''} and any(frag in exe for frag in DANGEROUS_PROCESS_PATH_FRAGMENTS):
		score += 1
	if any(token in cmdline for token in ('base64', 'curl ', 'wget ', 'nc ', 'socat ', 'mkfifo', 'chmod +x', '/dev/tcp/', 'nohup', 'setsid')):
		score += 2
	if exe == '' and cmdline:
		score += 1
	if proc.get('cwd', '').startswith('/tmp') or proc.get('cwd', '').startswith('/dev/shm'):
		score += 1
	if proc.get('listening_ports'):
		score += 1
	if ports & set(COMMON_SERVICE_PORTS) and exe.startswith(('/usr/', '/bin/', '/sbin/')) and username in SYSTEM_USERS | {'root'}:
		score = max(0, score - 2)
	return score


def severity_rank(level: str) -> int:
	return {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}.get(level, 0)


def diff_dict_sets(old_rows: list[dict[str, Any]], new_rows: list[dict[str, Any]], key: str) -> dict[str, list[dict[str, Any]]]:
	old = {str(row.get(key)): row for row in old_rows if row.get(key) is not None}
	new = {str(row.get(key)): row for row in new_rows if row.get(key) is not None}
	added = [new[k] for k in sorted(new.keys() - old.keys())]
	removed = [old[k] for k in sorted(old.keys() - new.keys())]
	changed = []
	for k in sorted(old.keys() & new.keys()):
		if old[k] != new[k]:
			changed.append({'before': old[k], 'after': new[k]})
	return {'added': added, 'removed': removed, 'changed': changed}


def build_alerts(current: dict[str, Any], baseline: dict[str, Any] | None) -> list[dict[str, Any]]:
	if not baseline:
		return []
	alerts: list[dict[str, Any]] = []
	users_diff = diff_dict_sets(baseline.get('users', []), current.get('users', []), 'name')
	for row in users_diff['added']:
		severity = 'high' if any(g in ADMIN_GROUPS for g in row.get('groups', [])) else 'medium'
		alerts.append({'severity': severity, 'kind': 'new_user', 'detail': row, 'host': current.get('host_id')})
	for row in users_diff['removed']:
		alerts.append({'severity': 'low', 'kind': 'removed_user', 'detail': row, 'host': current.get('host_id')})
	for row in users_diff['changed']:
		alerts.append({'severity': 'medium', 'kind': 'user_changed', 'detail': row, 'host': current.get('host_id')})

	listener_diff = diff_dict_sets(baseline.get('listeners', []), current.get('listeners', []), 'key')
	for row in listener_diff['added']:
		alerts.append({'severity': 'medium', 'kind': 'new_listener', 'detail': row, 'host': current.get('host_id')})
	for row in listener_diff['removed']:
		alerts.append({'severity': 'medium', 'kind': 'listener_removed', 'detail': row, 'host': current.get('host_id')})

	startup_diff = diff_dict_sets(baseline.get('startup_items', []), current.get('startup_items', []), 'key')
	for row in startup_diff['added']:
		alerts.append({'severity': 'high', 'kind': 'new_startup_item', 'detail': row, 'host': current.get('host_id')})
	for row in startup_diff['changed']:
		alerts.append({'severity': 'high', 'kind': 'startup_changed', 'detail': row, 'host': current.get('host_id')})

	persist_diff = diff_dict_sets(baseline.get('persistence_items', []), current.get('persistence_items', []), 'key')
	for row in persist_diff['added']:
		severity = 'high' if row.get('type') in HIGH_RISK_PERSISTENCE_TYPES else 'medium'
		alerts.append({'severity': severity, 'kind': 'new_persistence_item', 'detail': row, 'host': current.get('host_id')})
	for row in persist_diff['changed']:
		alerts.append({'severity': 'high', 'kind': 'persistence_changed', 'detail': row, 'host': current.get('host_id')})

	service_diff = diff_dict_sets(baseline.get('services', []), current.get('services', []), 'name')
	for row in service_diff['changed']:
		before = row['before']
		after = row['after']
		if before.get('active_state') != after.get('active_state'):
			alerts.append({'severity': 'high', 'kind': 'service_state_change', 'detail': row, 'host': current.get('host_id')})

	firewall_before = baseline.get('firewall', {})
	firewall_after = current.get('firewall', {})
	if firewall_before != firewall_after:
		alerts.append({'severity': 'medium', 'kind': 'firewall_changed', 'detail': {'before': firewall_before, 'after': firewall_after}, 'host': current.get('host_id')})

	for proc in current.get('processes', []):
		if proc.get('suspicion', 0) >= 4:
			alerts.append({'severity': 'medium' if proc.get('suspicion', 0) < 7 else 'high', 'kind': 'suspicious_process', 'detail': proc, 'host': current.get('host_id')})

	for health in current.get('health', []):
		if health.get('status') == 'down':
			severity = 'critical' if health.get('service') in {'ssh', 'dns', 'web', 'smb', 'postgres'} else 'high'
			alerts.append({'severity': severity, 'kind': 'service_down', 'detail': health, 'host': current.get('host_id')})
		elif health.get('status') == 'degraded':
			alerts.append({'severity': 'medium', 'kind': 'service_degraded', 'detail': health, 'host': current.get('host_id')})

	alerts.sort(key=lambda x: severity_rank(x['severity']), reverse=True)
	return alerts


def _is_privateish(ip: str) -> bool:
	try:
		addr = ipaddress.ip_address(ip)
		return addr.is_private or addr.is_loopback or addr.is_link_local
	except ValueError:
		return False


def classify_accounts(controller_started_at: str | None, hosts: dict[str, Any]) -> dict[str, dict[str, Any]]:
	started = parse_time(controller_started_at) or datetime.now(timezone.utc)
	window_end = started + timedelta(minutes=15)
	labels: dict[str, dict[str, Any]] = {}
	obs_by_user: dict[str, list[dict[str, Any]]] = defaultdict(list)
	user_meta: dict[str, list[dict[str, Any]]] = defaultdict(list)
	login_presence: dict[str, set[str]] = defaultdict(set)

	for host in hosts.values():
		for user in host.get('latest', {}).get('users', []):
			name = user.get('name')
			if not name:
				continue
			user_meta[name].append({'host': host.get('host_id'), **user})
		for row in host.get('latest', {}).get('logged_in_users', []):
			if row.get('username'):
				login_presence[row['username']].add(host.get('host_id'))
		for obs in host.get('observations', []):
			name = obs.get('username')
			if not name or name == '-':
				continue
			obs_by_user[name].append(obs)

	all_users = sorted(set(obs_by_user.keys()) | set(user_meta.keys()) | set(login_presence.keys()))
	for username in all_users:
		reasons: list[str] = []
		meta = user_meta.get(username, [])
		obs = obs_by_user.get(username, [])
		groups = {g for m in meta for g in m.get('groups', [])}
		shells = {m.get('shell', '') for m in meta}
		uids = {m.get('uid') for m in meta}
		source_ips = {o.get('source_ip') for o in obs if o.get('source_ip')}
		services = {o.get('service') for o in obs if o.get('service')}
		hosts_seen = {o.get('host_id') for o in obs if o.get('host_id')} | login_presence.get(username, set())
		actions = Counter(o.get('action') for o in obs)
		interactive_seen = bool(login_presence.get(username))

		label = 'unknown'
		confidence = 0.4

		if username in SYSTEM_USERS or any((uid is not None and int(uid) < 1000) for uid in uids if uid is not None):
			label = 'service_account'
			confidence = 0.95
			reasons.append('system/protected account')
		elif groups & ADMIN_GROUPS:
			label = 'admin'
			confidence = 0.9
			reasons.append('member of admin-capable group')
		elif any(shell in SHELL_LOGIN_DENY for shell in shells if shell):
			label = 'service_account'
			confidence = 0.85
			reasons.append('non-interactive shell')
		else:
			in_window = [o for o in obs if (parse_time(o.get('timestamp')) or started) <= window_end]
			window_services = {o.get('service') for o in in_window if o.get('service')}
			window_hosts = {o.get('host_id') for o in in_window if o.get('host_id')}
			window_ips = {o.get('source_ip') for o in in_window if o.get('source_ip')}
			if in_window and len(window_services) >= 2 and len(window_hosts) >= 1 and all(_is_privateish(ip) for ip in window_ips if ip):
				if set(actions.keys()) <= {'login_success', 'login_fail', 'read', 'write', 'query', 'http', 'dns'}:
					label = 'likely_scorer'
					confidence = 0.78
					reasons.append('early-window multi-service validation pattern')
			elif obs and any(not _is_privateish(ip) for ip in source_ips if ip):
				label = 'suspicious'
				confidence = 0.74
				reasons.append('observed from non-private source address')
			elif interactive_seen or any(action in actions for action in ('login_success', 'login_fail')):
				label = 'unknown_interactive'
				confidence = 0.58
				reasons.append('interactive account observed but not classified as scorer/service/admin')
			else:
				label = 'unknown'
				confidence = 0.45
				reasons.append('no observation data yet')

		labels[username] = {
			'username': username,
			'label': label,
			'confidence': round(confidence, 2),
			'reasons': reasons,
			'observation_count': len(obs),
			'source_ips': sorted(x for x in source_ips if x),
			'services': sorted(x for x in services if x),
			'hosts': sorted(x for x in hosts_seen if x),
			'groups': sorted(groups),
			'actions': dict(actions),
			'interactive_seen': interactive_seen,
		}
	return labels


def summarize_cross_host(hosts: dict[str, Any]) -> dict[str, Any]:
	remote_counter: Counter[str] = Counter()
	port_counter: Counter[int] = Counter()
	role_counter: Counter[str] = Counter()
	suspicious_users: set[str] = set()
	persist_counter: Counter[str] = Counter()
	for host in hosts.values():
		for conn in host.get('latest', {}).get('connections', []):
			remote = conn.get('remote_ip')
			if remote:
				remote_counter[remote] += 1
		for listener in host.get('latest', {}).get('listeners', []):
			port = listener.get('port')
			if isinstance(port, int):
				port_counter[port] += 1
		for role in host.get('roles', []):
			role_counter[role] += 1
		for user, info in host.get('account_labels', {}).items():
			if info.get('label') in {'suspicious', 'unknown_interactive'}:
				suspicious_users.add(user)
		for item in host.get('latest', {}).get('persistence_items', []):
			if item.get('type'):
				persist_counter[item['type']] += 1
	return {
		'top_remote_ips': [{'remote_ip': ip, 'count': count} for ip, count in remote_counter.most_common(20)],
		'common_ports': [{'port': port, 'count': count, 'service_guess': COMMON_SERVICE_PORTS.get(port, 'unknown')} for port, count in port_counter.most_common(20)],
		'roles': [{'role': role, 'count': count} for role, count in role_counter.most_common()],
		'suspicious_users': sorted(suspicious_users),
		'persistence_types': [{'type': name, 'count': count} for name, count in persist_counter.most_common(12)],
	}


def parse_prompt(text: str, hosts: dict[str, Any]) -> dict[str, Any]:
	query = text.strip()
	ql = query.lower()
	result: dict[str, Any] = {
		'query': query,
		'intents': [],
		'notes': [],
		'proposals': [],
		'filters': {},
	}
	if not query:
		result['notes'].append('No prompt text supplied.')
		return result

	service_aliases = {
		'ssh': ('ssh', 'sshd'),
		'dns': ('dns', 'named', 'bind'),
		'web': ('web', 'http', 'https', 'www', 'nginx', 'apache'),
		'smb': ('smb', 'samba', 'fileserver', 'file server'),
		'postgres': ('postgres', 'postgresql', 'database', 'db'),
	}
	selected_service = None
	for canonical, aliases in service_aliases.items():
		if any(alias in ql for alias in aliases):
			selected_service = canonical
			break
	if selected_service:
		result['filters']['service'] = selected_service

	selected_hosts: list[str] = []
	for host_id in hosts:
		if host_id.lower() in ql:
			selected_hosts.append(host_id)
	if not selected_hosts:
		selected_hosts = list(hosts.keys())
	result['filters']['hosts'] = selected_hosts

	if any(token in ql for token in ('show', 'list', 'find', 'summarize')):
		result['intents'].append('show')
	if any(token in ql for token in ('restart', 'reload', 'restore', 'baseline', 'rotate', 'lock', 'disable', 'delete', 'kill')):
		result['intents'].append('change')

	if 'new admin' in ql or 'unknown admin' in ql or 'privileged' in ql:
		result['filters']['account_labels'] = ['admin']
		result['notes'].append('Showing admin-capable accounts.')
	if 'scorer' in ql:
		result['filters']['account_labels'] = ['likely_scorer']
		result['notes'].append('Showing likely scorer accounts.')
	if 'unknown user' in ql or 'suspicious user' in ql:
		result['filters']['account_labels'] = ['unknown_interactive', 'suspicious']
		result['notes'].append('Showing unknown-interactive or suspicious users first.')
	if 'highest risk' in ql or 'top alert' in ql:
		result['filters']['highest_risk'] = True
		result['notes'].append('Highlighting hosts with the most severe alerts.')
	if 'weird process' in ql or 'suspicious process' in ql:
		result['filters']['suspicious_processes'] = True
		result['notes'].append('Highlighting processes with high suspicion scores.')
	if 'persistence' in ql:
		result['filters']['persistence'] = True
		result['notes'].append('Highlighting persistence artifacts and startup changes.')

	def add_proposal(action: str, severity: str, note: str, **kwargs: Any) -> None:
		result['proposals'].append({'action': action, 'severity': severity, 'note': note, **kwargs})

	if 'restart' in ql and selected_service:
		for host_id in selected_hosts:
			add_proposal('restart_service', 'yellow', f'Restart {selected_service} on {host_id}', host_id=host_id, service=selected_service)
	if 'reload' in ql and selected_service:
		for host_id in selected_hosts:
			add_proposal('reload_service', 'yellow', f'Reload {selected_service} on {host_id}', host_id=host_id, service=selected_service)
	if 'restore' in ql and selected_service:
		for host_id in selected_hosts:
			add_proposal('restore_service_config', 'yellow', f'Restore baseline config for {selected_service} on {host_id}', host_id=host_id, service=selected_service)
	if 'baseline' in ql or 'snapshot' in ql:
		for host_id in selected_hosts:
			add_proposal('create_baseline', 'yellow', f'Create or refresh baseline on {host_id}', host_id=host_id)
	if 'rotate' in ql and 'password' in ql:
		result['notes'].append('Use the host page or approvals page to supply new passwords for specific accounts.')
	if 'disable all other users' in ql or 'disable other users' in ql or 'lock other users' in ql:
		for host_id in selected_hosts:
			add_proposal('stage_bulk_lock_unknown_users', 'red', f'Stage locks for non-protected unknown-interactive or suspicious accounts on {host_id}', host_id=host_id)
	if 'kill suspicious processes' in ql or ('kill' in ql and 'process' in ql):
		for host_id in selected_hosts:
			add_proposal('stage_kill_suspicious_processes', 'red', f'Stage termination of high-suspicion non-critical processes on {host_id}', host_id=host_id)

	if not result['proposals'] and 'show' not in result['intents']:
		result['notes'].append('No direct action was inferred. Use phrases like “restart ssh on host1” or “show suspicious users”.')
	return result


def scorer_window_remaining(controller_started_at: str | None) -> int:
	started = parse_time(controller_started_at) or datetime.now(timezone.utc)
	remaining = (started + timedelta(minutes=15)) - datetime.now(timezone.utc)
	return max(0, int(remaining.total_seconds()))
