from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import socket
import ssl
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def utc_now() -> str:
	return datetime.now(timezone.utc).isoformat()


def ensure_dir(path: str | Path) -> Path:
	p = Path(path)
	p.mkdir(parents=True, exist_ok=True)
	return p


def read_json(path: str | Path, default: Any = None) -> Any:
	p = Path(path)
	if not p.exists():
		return default
	with p.open('r', encoding='utf-8') as fh:
		return json.load(fh)


def write_json(path: str | Path, data: Any) -> None:
	p = Path(path)
	p.parent.mkdir(parents=True, exist_ok=True)
	with p.open('w', encoding='utf-8') as fh:
		json.dump(data, fh, indent=2, sort_keys=True)


def append_jsonl(path: str | Path, row: dict[str, Any]) -> None:
	p = Path(path)
	p.parent.mkdir(parents=True, exist_ok=True)
	with p.open('a', encoding='utf-8') as fh:
		fh.write(json.dumps(row, sort_keys=True) + '\n')


def digest_text(text: str) -> str:
	return hashlib.sha256(text.encode('utf-8', errors='ignore')).hexdigest()


def sha256_file(path: str | Path) -> str | None:
	p = Path(path)
	if not p.exists() or not p.is_file():
		return None
	h = hashlib.sha256()
	with p.open('rb') as fh:
		for chunk in iter(lambda: fh.read(65536), b''):
			h.update(chunk)
	return h.hexdigest()


def safe_run(cmd: Iterable[str], timeout: int = 20) -> tuple[int, str, str]:
	try:
		proc = subprocess.run(list(cmd), capture_output=True, text=True, timeout=timeout, check=False)
		return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
	except Exception as exc:
		return 1, '', f'{type(exc).__name__}: {exc}'


def shell_escape(parts: Iterable[str]) -> str:
	return ' '.join(shlex.quote(x) for x in parts)


def tcp_connect(host: str, port: int, timeout: float = 2.0) -> bool:
	try:
		with socket.create_connection((host, port), timeout=timeout):
			return True
	except OSError:
		return False


def http_probe(url: str, timeout: float = 3.0, verify_tls: bool = False) -> tuple[bool, int | None, str]:
	try:
		ctx = None
		if url.lower().startswith('https://') and not verify_tls:
			ctx = ssl._create_unverified_context()
		with urllib.request.urlopen(url, timeout=timeout, context=ctx) as resp:
			body = resp.read(8192).decode('utf-8', errors='ignore')
			return True, getattr(resp, 'status', 200), body
	except urllib.error.HTTPError as exc:
		try:
			body = exc.read(4096).decode('utf-8', errors='ignore')
		except Exception:
			body = ''
		return False, exc.code, body
	except Exception as exc:
		return False, None, str(exc)


def dedupe_by_key(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
	seen: set[str] = set()
	out: list[dict[str, Any]] = []
	for row in rows:
		value = str(row.get(key, ''))
		if value in seen:
			continue
		seen.add(value)
		out.append(row)
	return out


def bounded_list(items: list[Any], max_items: int) -> list[Any]:
	if len(items) <= max_items:
		return items
	return items[-max_items:]


def env_flag(name: str, default: bool = False) -> bool:
	val = os.environ.get(name)
	if val is None:
		return default
	return val.strip().lower() in {'1', 'true', 'yes', 'on'}


def command_exists(name: str) -> bool:
	return shutil.which(name) is not None
