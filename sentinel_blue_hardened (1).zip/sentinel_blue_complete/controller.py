from __future__ import annotations

import argparse
import copy
import os
import threading
import uuid
from pathlib import Path
from typing import Any

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for

from rules import ADMIN_GROUPS, COMMON_SERVICE_PORTS, build_alerts, classify_accounts, infer_roles, parse_prompt, scorer_window_remaining, summarize_cross_host
from shared import append_jsonl, ensure_dir, read_json, utc_now, write_json

APP = Flask(__name__)
APP.secret_key = os.environ.get('SENTINEL_BLUE_SECRET') or os.urandom(32).hex()
DEFAULT_BIND = '127.0.0.1'
DEFAULT_PORT = 8989
STATE_DIR = ensure_dir(Path('./sentinel_blue_controller_state'))
STATE_FILE = STATE_DIR / 'state.json'
EVENTS_FILE = STATE_DIR / 'events.jsonl'
ALLOWED_ACTIONS = {
	'create_baseline', 'restart_service', 'reload_service', 'restore_service_config', 'lock_user', 'disable_user',
	'delete_user', 'terminate_user_sessions', 'kill_process', 'rotate_password',
}


class ControllerState:
	def __init__(self) -> None:
		self.lock = threading.Lock()
		self.data: dict[str, Any] = read_json(STATE_FILE, default=None) or {
			'controller_started_at': utc_now(),
			'token': None,
			'hosts': {},
			'pending_actions': [],
			'completed_actions': [],
		}

	def save(self) -> None:
		write_json(STATE_FILE, self.data)

	def append_event(self, event: dict[str, Any]) -> None:
		append_jsonl(EVENTS_FILE, event)

	def ensure_token(self, token: str | None) -> None:
		if token and not self.data.get('token'):
			self.data['token'] = token
			self.save()

	def require_token(self, token: str | None) -> bool:
		expected = self.data.get('token')
		if not expected:
			return True
		return bool(token and token == expected)

	def refresh_account_labels(self) -> None:
		labels = classify_accounts(self.data.get('controller_started_at'), self.data.get('hosts', {}))
		for host in self.data['hosts'].values():
			host['account_labels'] = {u: labels.get(u, {'username': u, 'label': 'unknown', 'confidence': 0.4, 'reasons': []}) for u in host.get('user_index', {})}
			host['protected_users'] = self.protected_usernames_for_host(host.get('host_id', ''))

	def protected_usernames_for_host(self, host_id: str) -> list[str]:
		host = self.data['hosts'].get(host_id, {})
		protected: set[str] = {'root'}
		for username, info in host.get('account_labels', {}).items():
			if info.get('label') in {'likely_scorer', 'service_account', 'admin'}:
				protected.add(username)
		for row in host.get('latest', {}).get('logged_in_users', []):
			if row.get('username'):
				protected.add(row['username'])
		protected.update(host.get('protected_users', []))
		return sorted(protected)

	def ingest_report(self, report: dict[str, Any]) -> None:
		host_id = report['host_id']
		host_state = self.data['hosts'].setdefault(host_id, {
			'host_id': host_id,
			'first_seen': utc_now(),
			'baseline': None,
			'observations': [],
			'protected_users': [],
		})
		latest = copy.deepcopy(report)
		latest['roles'] = infer_roles(latest)
		baseline = host_state.get('baseline')
		alerts = build_alerts(latest, baseline)
		host_state['host_id'] = host_id
		host_state['last_seen'] = utc_now()
		host_state['latest'] = latest
		host_state['roles'] = latest['roles']
		host_state['alerts'] = alerts
		host_state['health_summary'] = {
			'up': sum(1 for x in latest.get('health', []) if x.get('status') == 'up'),
			'degraded': sum(1 for x in latest.get('health', []) if x.get('status') == 'degraded'),
			'down': sum(1 for x in latest.get('health', []) if x.get('status') == 'down'),
		}
		host_state['user_index'] = {u['name']: u for u in latest.get('users', []) if u.get('name')}
		for observation in report.get('observations', []):
			obs = dict(observation)
			obs['host_id'] = host_id
			host_state.setdefault('observations', []).append(obs)
		host_state['observations'] = host_state.get('observations', [])[-2500:]
		if host_state.get('baseline') is None:
			host_state['baseline'] = copy.deepcopy(latest)
			self.append_event({'timestamp': utc_now(), 'kind': 'baseline_created', 'host_id': host_id})
		self.refresh_account_labels()
		self.save()

	def _duplicate_pending(self, host_id: str, action: str, params: dict[str, Any]) -> dict[str, Any] | None:
		for item in self.data.get('pending_actions', []):
			if item.get('host_id') == host_id and item.get('action') == action and item.get('params') == params and item.get('status') in {'pending_approval', 'approved'}:
				return item
		return None

	def create_action(self, host_id: str, action: str, params: dict[str, Any], severity: str = 'yellow', note: str = '') -> dict[str, Any]:
		if action not in ALLOWED_ACTIONS:
			raise ValueError(f'unsupported action: {action}')
		if host_id not in self.data.get('hosts', {}):
			raise ValueError(f'unknown host: {host_id}')
		duplicate = self._duplicate_pending(host_id, action, params)
		if duplicate:
			return duplicate
		item = {
			'id': str(uuid.uuid4()),
			'created_at': utc_now(),
			'host_id': host_id,
			'action': action,
			'params': params,
			'severity': severity,
			'note': note,
			'status': 'pending_approval',
			'result': None,
		}
		self.data['pending_actions'].append(item)
		self.append_event({'timestamp': utc_now(), 'kind': 'action_created', 'action_id': item['id'], 'host_id': host_id, 'action': action, 'severity': severity})
		self.save()
		return item

	def get_action(self, action_id: str) -> dict[str, Any] | None:
		for row in self.data.get('pending_actions', []):
			if row['id'] == action_id:
				return row
		for row in self.data.get('completed_actions', []):
			if row['id'] == action_id:
				return row
		return None

	def approve(self, action_id: str) -> bool:
		item = self.get_action(action_id)
		if not item or item['status'] != 'pending_approval':
			return False
		item['status'] = 'approved'
		item['approved_at'] = utc_now()
		self.append_event({'timestamp': utc_now(), 'kind': 'action_approved', 'action_id': action_id})
		self.save()
		return True

	def reject(self, action_id: str) -> bool:
		item = self.get_action(action_id)
		if not item or item['status'] not in {'pending_approval', 'approved'}:
			return False
		item['status'] = 'rejected'
		item['rejected_at'] = utc_now()
		self.append_event({'timestamp': utc_now(), 'kind': 'action_rejected', 'action_id': action_id})
		self.save()
		return True

	def fetch_approved_actions(self, host_id: str) -> list[dict[str, Any]]:
		rows = []
		for item in self.data.get('pending_actions', []):
			if item.get('host_id') == host_id and item.get('status') == 'approved' and not item.get('dispatched_at'):
				item['dispatched_at'] = utc_now()
				rows.append(item)
		self.save()
		return rows

	def complete_action(self, action_id: str, result: dict[str, Any]) -> bool:
		for idx, item in enumerate(self.data.get('pending_actions', [])):
			if item['id'] == action_id:
				item['status'] = 'completed' if result.get('ok') else 'failed'
				item['completed_at'] = utc_now()
				item['result'] = result
				self.data['completed_actions'].append(item)
				del self.data['pending_actions'][idx]
				self.append_event({'timestamp': utc_now(), 'kind': 'action_completed', 'action_id': action_id, 'ok': result.get('ok', False)})
				self.save()
				return True
		return False

	def create_baseline(self, host_id: str) -> bool:
		host = self.data['hosts'].get(host_id)
		if not host or not host.get('latest'):
			return False
		host['baseline'] = copy.deepcopy(host['latest'])
		self.append_event({'timestamp': utc_now(), 'kind': 'baseline_refreshed', 'host_id': host_id})
		self.save()
		return True

	def bulk_stage_unknown_user_actions(self, host_id: str, mode: str = 'lock', include_session_kill: bool = True) -> list[dict[str, Any]]:
		host = self.data['hosts'].get(host_id)
		if not host:
			return []
		labels = host.get('account_labels', {})
		protected = set(self.protected_usernames_for_host(host_id))
		created: list[dict[str, Any]] = []
		for username, info in sorted(labels.items()):
			if info.get('label') not in {'unknown_interactive', 'suspicious'}:
				continue
			if info.get('confidence', 0) < 0.55:
				continue
			user_row = host.get('user_index', {}).get(username, {})
			groups = set(user_row.get('groups', []))
			if username in protected or groups & ADMIN_GROUPS:
				continue
			action = 'lock_user' if mode == 'lock' else 'disable_user' if mode == 'disable' else 'delete_user'
			created.append(self.create_action(host_id, action, {'username': username}, severity='red', note=f'Staged bulk {action} for {username}'))
			if include_session_kill and mode in {'lock', 'disable'}:
				created.append(self.create_action(host_id, 'terminate_user_sessions', {'username': username}, severity='red', note=f'Staged session termination for {username}'))
		return created

	def bulk_stage_suspicious_process_kills(self, host_id: str) -> list[dict[str, Any]]:
		host = self.data['hosts'].get(host_id)
		if not host:
			return []
		created: list[dict[str, Any]] = []
		for proc in host.get('latest', {}).get('processes', []):
			ports = {int(p) for p in proc.get('listening_ports', []) if isinstance(p, int)}
			if proc.get('suspicion', 0) >= 7 and not (ports & set(COMMON_SERVICE_PORTS)):
				created.append(self.create_action(host_id, 'kill_process', {'pid': proc['pid']}, severity='red', note=f"Kill suspicious non-critical process {proc.get('name')} ({proc.get('pid')})"))
		return created


STATE = ControllerState()


def _require_api_token() -> tuple[bool, Any]:
	token = request.headers.get('X-Sentinel-Token') or request.args.get('token')
	if not STATE.require_token(token):
		return False, (jsonify({'ok': False, 'error': 'unauthorized'}), 403)
	return True, None


@APP.route('/')
def dashboard() -> str:
	with STATE.lock:
		hosts = copy.deepcopy(STATE.data['hosts'])
		pending = [x for x in STATE.data.get('pending_actions', []) if x['status'] in {'pending_approval', 'approved'}]
		completed = list(reversed(STATE.data.get('completed_actions', [])[-20:]))
		cross = summarize_cross_host(hosts)
		window_remaining = scorer_window_remaining(STATE.data.get('controller_started_at'))
	return render_template('dashboard.html', hosts=hosts, pending=pending, completed=completed, cross=cross, window_remaining=window_remaining)


@APP.route('/prompt', methods=['POST'])
def prompt_router() -> Any:
	text = request.form.get('prompt', '').strip()
	with STATE.lock:
		parsed = parse_prompt(text, STATE.data.get('hosts', {}))
		created = 0
		for proposal in parsed.get('proposals', []):
			action = proposal['action']
			host_id = proposal['host_id']
			if action == 'stage_bulk_lock_unknown_users':
				created += len(STATE.bulk_stage_unknown_user_actions(host_id, mode='lock', include_session_kill=True))
			elif action == 'stage_kill_suspicious_processes':
				created += len(STATE.bulk_stage_suspicious_process_kills(host_id))
			else:
				params = {k: v for k, v in proposal.items() if k not in {'action', 'severity', 'note', 'host_id'}}
				STATE.create_action(host_id, action, params, severity=proposal.get('severity', 'yellow'), note=proposal.get('note', ''))
				created += 1
		STATE.save()
	flash(f'Parsed prompt. Created {created} staged action(s).', 'info')
	return render_template('prompt_result.html', parsed=parsed, created=created, hosts=STATE.data.get('hosts', {}))


@APP.route('/host/<host_id>')
def host_detail(host_id: str) -> Any:
	with STATE.lock:
		host = copy.deepcopy(STATE.data['hosts'].get(host_id))
		if not host:
			flash(f'Host {host_id} not found.', 'error')
			return redirect(url_for('dashboard'))
		pending = [x for x in STATE.data.get('pending_actions', []) if x.get('host_id') == host_id]
	return render_template('host.html', host=host, pending=pending)


@APP.route('/scorers')
def scorers() -> str:
	with STATE.lock:
		hosts = copy.deepcopy(STATE.data['hosts'])
		labels = classify_accounts(STATE.data.get('controller_started_at'), hosts)
		window_remaining = scorer_window_remaining(STATE.data.get('controller_started_at'))
	return render_template('scorers.html', labels=labels, hosts=hosts, window_remaining=window_remaining)


@APP.route('/approvals')
def approvals() -> str:
	with STATE.lock:
		pending = [x for x in STATE.data.get('pending_actions', []) if x['status'] in {'pending_approval', 'approved'}]
		completed = list(reversed(STATE.data.get('completed_actions', [])[-100:]))
	return render_template('approvals.html', pending=pending, completed=completed)


@APP.post('/approve/<action_id>')
def approve_action(action_id: str) -> Any:
	with STATE.lock:
		ok = STATE.approve(action_id)
	flash('Action approved.' if ok else 'Action not found or not pending.', 'info' if ok else 'error')
	return redirect(request.referrer or url_for('approvals'))


@APP.post('/reject/<action_id>')
def reject_action(action_id: str) -> Any:
	with STATE.lock:
		ok = STATE.reject(action_id)
	flash('Action rejected.' if ok else 'Action not found or not rejectable.', 'info' if ok else 'error')
	return redirect(request.referrer or url_for('approvals'))


@APP.post('/baseline/<host_id>')
def refresh_baseline(host_id: str) -> Any:
	with STATE.lock:
		ok = STATE.create_baseline(host_id)
	flash('Baseline refreshed.' if ok else 'Unable to refresh baseline.', 'info' if ok else 'error')
	return redirect(request.referrer or url_for('host_detail', host_id=host_id))


@APP.post('/bulk/<host_id>/lock_unknown')
def bulk_lock_unknown(host_id: str) -> Any:
	with STATE.lock:
		created = STATE.bulk_stage_unknown_user_actions(host_id, mode='lock', include_session_kill=True)
	flash(f'Staged {len(created)} lock/session actions for unknown-interactive or suspicious users.', 'info')
	return redirect(request.referrer or url_for('host_detail', host_id=host_id))


@APP.post('/bulk/<host_id>/disable_unknown')
def bulk_disable_unknown(host_id: str) -> Any:
	with STATE.lock:
		created = STATE.bulk_stage_unknown_user_actions(host_id, mode='disable', include_session_kill=True)
	flash(f'Staged {len(created)} disable/session actions for unknown-interactive or suspicious users.', 'info')
	return redirect(request.referrer or url_for('host_detail', host_id=host_id))


@APP.post('/bulk/<host_id>/delete_unknown')
def bulk_delete_unknown(host_id: str) -> Any:
	with STATE.lock:
		created = STATE.bulk_stage_unknown_user_actions(host_id, mode='delete', include_session_kill=False)
	flash(f'Staged {len(created)} delete actions for unknown-interactive or suspicious users.', 'info')
	return redirect(request.referrer or url_for('host_detail', host_id=host_id))


@APP.post('/bulk/<host_id>/kill_suspicious_processes')
def bulk_kill_suspicious_processes(host_id: str) -> Any:
	with STATE.lock:
		created = STATE.bulk_stage_suspicious_process_kills(host_id)
	flash(f'Staged {len(created)} suspicious process termination actions.', 'info')
	return redirect(request.referrer or url_for('host_detail', host_id=host_id))


@APP.post('/action/create')
def create_manual_action() -> Any:
	host_id = request.form.get('host_id', '').strip()
	action = request.form.get('action', '').strip()
	severity = request.form.get('severity', 'yellow').strip()
	note = request.form.get('note', '').strip()
	params = {}
	for key in ['service', 'username', 'pid', 'path', 'new_password']:
		value = request.form.get(key, '').strip()
		if value:
			params[key] = int(value) if key == 'pid' else value
	with STATE.lock:
		try:
			STATE.create_action(host_id, action, params, severity=severity, note=note)
		except ValueError as exc:
			flash(str(exc), 'error')
			return redirect(request.referrer or url_for('approvals'))
	flash('Manual action staged for approval.', 'info')
	return redirect(request.referrer or url_for('approvals'))


@APP.route('/api/heartbeat', methods=['POST'])
def api_heartbeat() -> Any:
	ok, response = _require_api_token()
	if not ok:
		return response
	payload = request.get_json(force=True, silent=False)
	if not isinstance(payload, dict) or 'host_id' not in payload:
		return jsonify({'ok': False, 'error': 'invalid payload'}), 400
	with STATE.lock:
		STATE.ingest_report(payload)
	return jsonify({'ok': True, 'server_time': utc_now()})


@APP.route('/api/commands/<host_id>', methods=['GET'])
def api_commands(host_id: str) -> Any:
	ok, response = _require_api_token()
	if not ok:
		return response
	with STATE.lock:
		commands = STATE.fetch_approved_actions(host_id)
	return jsonify({'ok': True, 'commands': commands})


@APP.route('/api/command_result/<action_id>', methods=['POST'])
def api_command_result(action_id: str) -> Any:
	ok, response = _require_api_token()
	if not ok:
		return response
	payload = request.get_json(force=True, silent=False)
	with STATE.lock:
		done = STATE.complete_action(action_id, payload)
	if not done:
		return jsonify({'ok': False, 'error': 'unknown action'}), 404
	return jsonify({'ok': True})


@APP.route('/api/state', methods=['GET'])
def api_state() -> Any:
	ok, response = _require_api_token()
	if not ok:
		return response
	with STATE.lock:
		return jsonify({'ok': True, 'state': STATE.data})


def main() -> None:
	parser = argparse.ArgumentParser(description='Sentinel Blue Controller')
	parser.add_argument('--bind', default=DEFAULT_BIND)
	parser.add_argument('--port', type=int, default=DEFAULT_PORT)
	parser.add_argument('--token', default=os.environ.get('SENTINEL_BLUE_TOKEN', ''))
	args = parser.parse_args()
	with STATE.lock:
		STATE.ensure_token(args.token or None)
	APP.run(host=args.bind, port=args.port, debug=False, threaded=True)


if __name__ == '__main__':
	main()
