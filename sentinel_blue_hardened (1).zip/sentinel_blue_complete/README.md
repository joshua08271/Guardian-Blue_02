# Sentinel Blue

Sentinel Blue is a Linux-first blue-team controller and host agent designed for cyber defense competitions and lab environments where uptime matters more than elegant theory.

It is built around these ideas:

- one controller on the physical machine
- one lightweight agent on each Linux host
- adaptive discovery instead of hard-coded hostnames
- service modules for SSH, DNS, web, SMB, Postgres, and generic Linux hosts
- a 15-minute scorer-learning window that labels likely scorer accounts from observed behavior
- confirmation gates before anything disruptive
- safer bulk actions that target only `unknown_interactive` or `suspicious` accounts, not every unknown account
- deeper persistence visibility and stricter protection around system and scorer/service accounts

This build is defensive and human-in-the-loop.

## What it does

- discovers host OS, users, groups, services, packages, listeners, connections, logged-in users, cron/systemd persistence, authorized keys, sudoers paths, shell-startup files, and suspicious processes
- infers likely roles such as `ssh`, `dns`, `web`, `smb`, `database`, and `router`
- keeps a baseline per host and highlights drift, including persistence drift
- watches auth and service logs to build account labels like:
  - `likely_scorer`
  - `service_account`
  - `admin`
  - `unknown`
  - `unknown_interactive`
  - `suspicious`
- stages actions that require approval, such as:
  - restart/reload service
  - restore baseline service config
  - lock/disable/delete account
  - terminate user sessions
  - kill suspicious process
  - rotate password
- lets you type plain-English-ish prompts into the UI and turns them into staged actions
- validates service health after disruptive actions so the controller can show whether key services stayed up

## What it does not do

- no snapshots
- no stealth or persistence
- no arbitrary remote shell execution
- no cloud dependency
- no automatic deletion of all unknown users without approval

The UI **can** stage bulk lock/disable/delete actions, but those bulk actions now skip:

- `root`
- likely scorers
- service accounts
- admin accounts
- currently logged-in users
- low-confidence unknowns with no interactive evidence

## Service handling

This build is structured around service capabilities rather than fixed hostnames. It directly supports discovery and health tracking for the kinds of checks shown in your screenshot:

- Router ICMP / routing host behavior
- SSH login reachability
- SMB listener and config sanity
- WWW port 80 / SSL with optional content checks
- Postgres reachability with `pg_isready` when available
- DNS responsiveness with `dig` when available

Without an expectations file, service checks stay conservative. With an expectations file, health checks become much stronger.

## Install

Use Python 3.10+.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Start the controller on the physical machine

Choose a shared token first.

```bash
export SENTINEL_BLUE_TOKEN='replace-this-with-a-team-secret'
python controller.py --bind 0.0.0.0 --port 8989 --token "$SENTINEL_BLUE_TOKEN"
```

Then open the UI:

```text
http://PHYSICAL-MACHINE-IP:8989
```

## Start the agent on each Linux host

```bash
export SENTINEL_BLUE_TOKEN='replace-this-with-a-team-secret'
python agent.py \
  --controller http://PHYSICAL-MACHINE-IP:8989 \
  --token "$SENTINEL_BLUE_TOKEN" \
  --interval 15
```

Optional expectations file:

```bash
python agent.py \
  --controller http://PHYSICAL-MACHINE-IP:8989 \
  --token "$SENTINEL_BLUE_TOKEN" \
  --interval 15 \
  --expectations example_expectations.json
```

## Expectations file

The expectations file is where you make service checks scoring-aware.

Example:

```json
{
  "web": {
    "url": "http://127.0.0.1/",
    "https_url": "https://127.0.0.1/",
    "contains": "Welcome"
  },
  "dns": {
    "server": "127.0.0.1",
    "query_name": "localhost",
    "query_type": "A"
  },
  "postgres": {
    "port": 5432,
    "database": "postgres"
  }
}
```

## Recommended first-30-minute workflow

1. start the controller
2. start all agents
3. let the scorer-learning window run for 10–15 minutes
4. review `Users & scorers`
5. review each host page, especially `Health`, `Alerts`, and `Persistence artifacts`
6. refresh baselines once core services are in a good state
7. stage only low-risk actions first
8. use bulk account actions only after scorer/service/admin labels look reasonable

## Prompt examples

These go into the prompt box on the controller dashboard.

- `show suspicious users`
- `show scorers`
- `show highest risk hosts`
- `show persistence`
- `restart ssh on web01`
- `restore dns on dns01`
- `disable other users on fileserver`
- `kill suspicious processes on db01`
- `refresh baseline on all hosts`

## Safety notes

- run this only where you are authorized
- prefer `lock` or `disable` before `delete`
- revalidate services immediately after approving risky actions
- refresh baselines only after the host is in a clean good state
- do not rotate service-account or scorer-account passwords unless you know exactly what depends on them
- do not approve `delete_user` or `kill_process` just because the label says suspicious; review service impact first

## Files and state

Controller state is stored in:

```text
./sentinel_blue_controller_state/
```

Agent state and baselines are stored in:

```text
~/.sentinel_blue_agent/
```
